let myColor; // Declare myColor outside the intervals
const fadeElement = document.createElement("div");
fadeElement.style.opacity=0
fadeElement.style.transition = "opacity 1s";
fadeElement.style.fontSize = '3rem';
fadeElement.style.position = "fixed";
fadeElement.style.zIndex=1000
fadeElement.style.top = "50%";
fadeElement.style.left = "50%";
fadeElement.style.transform = "translate(-50%, -50%)";
fadeElement.style.fontWeight = 900
fadeElement.style.fontFamily="cursive"
fadeElement.style.padding = '.5em'
fadeElement.style.backgroundColor='#80008045'
fadeElement.style.borderRadius='10px'
document.body.appendChild(fadeElement)

//fetching audio files
const audioWin = new Audio(chrome.runtime.getURL('./win.mp3')); 
const audioLoose = new Audio(chrome.runtime.getURL('./lose.mp3')); 
//fetching important data
const userName=document.getElementById('user_tag').innerText
const gamePlayers=document.querySelectorAll('div.game__meta__players div')
gamePlayers.forEach(item=>{
    if(item.querySelector('a')){
        let url=new URL(item.querySelector('a').href).pathname.replace('/@/','')
        if(url===userName){
            myColor=item.classList[3]
        }
    }
})
    const id1 = setInterval(() => {
        const winnerStatement = document.querySelector('section.status');
        if (winnerStatement) {
            clearInterval(id1); // Clear the second interval
            if (winnerStatement.innerText.includes("Black is victorious")) {
                winnerPlayerColor = 'black';
            } else {
                winnerPlayerColor = 'white';
            }
            determineWinningStatement(); // Call the function to determine the winning statement
        }
    }, 1000);

function determineWinningStatement() {
    if (myColor === winnerPlayerColor) {
        doThing(audioWin,'Flawless Victory')
    } else {
        doThing(audioLoose,'Fatality')
    }
}
const doThing=(file,statement)=>{
    file.play()
    if(statement==='Fatality'){
        fadeElement.style.color='red'
    }else{
        fadeElement.style.color="purple"
    }
fadeElement.textContent = statement;
// Center the element vertically and horizontally
    fadeElement.style.opacity = 1;
    // After 2 seconds, fade out
    setTimeout(() => {
        fadeElement.style.opacity = 0;
    }, 2000); 
}